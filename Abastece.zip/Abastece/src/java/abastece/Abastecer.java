/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abastece;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/**
 *
 * @author fernandams
 */
@Named(value = "abastecer")
@RequestScoped
public class Abastecer {
    
    private float precoGasolina;
    private float precoAlcool;
    private float custo;   
    private String situacao;


    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }
 
    public float getPrecoGasolina() {
        return precoGasolina;
    }

    public void setPrecoGasolina(float precoGasolina) {
        this.precoGasolina = precoGasolina;
    }

    public float getPrecoAlcool() {
        return precoAlcool;
    }

    public void setPrecoAlcool(float precoAlcool) {
        this.precoAlcool = precoAlcool;
    }

    public float getCusto() {
        return custo;
    }

    public void setCusto(float custo) {
        this.custo = custo;
    }
    
    public String calcularCusto(){
        custo = (70 * precoGasolina) / 100;
        if(precoAlcool < custo){
            situacao = "Compensa abastecer com álcool";
        }
        else if(precoAlcool > custo){
            situacao = "Não compensa abastecer com alcool";
        }
        else{
            situacao = "Mesmo custo";
        }
        return "/custo";
    }
    
}
